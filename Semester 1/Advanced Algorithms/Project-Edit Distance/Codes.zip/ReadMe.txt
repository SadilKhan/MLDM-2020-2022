 Algorithms.ipynb ---> Source code for all the seven algorithms
 
 Protein and Artificial Data Analysis.ipynb --> Code for analysis

 artifi.csv --> Dataset which contains analysis for Artificial Dataset
 
 protein_analysis.csv --> Dataset which contains analysis for Artificial Dataset
 
 kvalues.csv --> Dataset which contains analysis and comparison for different values of k in K-                              Diagonal algorithm.
